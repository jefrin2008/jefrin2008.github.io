BOUNCE BALL DELUXE
Version 1.0.0

Platform:
Windows 10 / Windows 11

How to Play:
Double-click BOUNCE_BALL_DELUXE.exe

Controls:
WASD / Arrow Keys - Move
Space - Jump
Esc - Pause / Exit

Created by:
Jefrin